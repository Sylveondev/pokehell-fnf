function onEvent(name, value1, value2)
   if name == 'bgremove' then
    onEndSong()
    
    
    
    
    end
end
